//
//  DisplayPluginsWithDefaultArrayController.h
//  Growl
//
//  Created by Evan Schoenberg on 8/18/07.
//

#import <Cocoa/Cocoa.h>

@interface DisplayPluginsWithDefaultArrayController : NSArrayController {

}

@end
